# Learning Golang notes

- S01B00 - Kafka and Golang


